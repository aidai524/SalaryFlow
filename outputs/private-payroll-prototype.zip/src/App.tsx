import { useCallback, useRef, useState } from "react";
import { initialAuditEvents, recipients } from "./data";
import { DialogLayer } from "./components/Dialogs";
import { PayrollView } from "./components/PayrollView";
import { SecondaryViews } from "./components/SecondaryViews";
import { Shell } from "./components/Shell";
import type { AuditEvent, DialogKind, Screen } from "./model";

type RunState = "pending" | "approved" | "executed";

function App() {
  const [screen, setScreen] = useState<Screen>("payroll");
  const [selectedId, setSelectedId] = useState("chen-wei");
  const [revealedIds, setRevealedIds] = useState<Set<string>>(() => new Set());
  const [runState, setRunState] = useState<RunState>("pending");
  const [dialog, setDialog] = useState<DialogKind>("none");
  const [events, setEvents] = useState<AuditEvent[]>(initialAuditEvents);
  const [toast, setToast] = useState("");
  const toastTimer = useRef<number | null>(null);

  const showToast = useCallback((message: string) => {
    setToast(message);
    if (toastTimer.current) window.clearTimeout(toastTimer.current);
    toastTimer.current = window.setTimeout(() => setToast(""), 3600);
  }, []);

  const addEvent = useCallback(
    (action: string, purpose: string, result: string) => {
      const now = new Date();
      const event: AuditEvent = {
        id: `${now.getTime()}-${action}`,
        time: `今天 ${now.toLocaleTimeString("zh-CN", {
          hour: "2-digit",
          minute: "2-digit",
          hour12: false,
        })}`,
        actor: "Operator",
        action,
        purpose,
        result,
      };
      setEvents((current) => [...current, event]);
    },
    [],
  );

  const grantAccess = (id: string, reason: string, ticket: string) => {
    const person = recipients.find((recipient) => recipient.id === id);
    setRevealedIds((current) => new Set(current).add(id));
    addEvent(
      `临时解封 ${person?.name ?? id} 的净额`,
      `${reason} · ${ticket}`,
      "30 分钟访问模拟",
    );
    showToast("已临时显示该净额；这只是界面状态，不代表数据已解密。 ");
  };

  const hideAmount = (id: string) => {
    const wasRevealed = revealedIds.has(id);
    setRevealedIds((current) => {
      const next = new Set(current);
      next.delete(id);
      return next;
    });
    if (wasRevealed) {
      const person = recipients.find((recipient) => recipient.id === id);
      addEvent(`重新隐藏 ${person?.name ?? id} 的净额`, "访问结束", "已隐藏");
      showToast("个人净额已重新隐藏。 ");
    }
  };

  const confirmApprove = () => {
    setRunState("approved");
    setDialog("none");
    addEvent("批准 8 月薪资批次 v1", "月度工资复核", "本地审批已记录");
    showToast("审批已记录；未验证身份或真实签名。 ");
  };

  const confirmExecute = () => {
    setRunState("executed");
    setDialog("none");
    addEvent("完成支付状态模拟", "演示支付闭环", "未发送资金");
    showToast("状态模拟已完成，没有发送资金。 ");
  };

  const createBatch = (name: string, date: string, currency: string) => {
    setDialog("none");
    addEvent(`创建 ${name}`, `计划日 ${date}`, `${currency} · 会话内草稿`);
    showToast(`${name} 已作为会话内草稿记录；刷新后会消失。`);
  };

  const resetDemo = () => {
    setRunState("pending");
    setRevealedIds(new Set());
    setEvents(initialAuditEvents);
    setSelectedId("chen-wei");
    setDialog("none");
    showToast("演示状态已重置。 ");
  };

  return (
    <>
      <Shell screen={screen} onNavigate={setScreen}>
        {screen === "payroll" ? (
          <PayrollView
            recipients={recipients}
            selectedId={selectedId}
            revealedIds={revealedIds}
            runState={runState}
            onSelect={setSelectedId}
            onGrantAccess={grantAccess}
            onHide={hideAmount}
            onOpenDialog={setDialog}
          />
        ) : (
          <SecondaryViews
            screen={screen}
            recipients={recipients}
            events={events}
            runState={runState}
            onNavigate={setScreen}
            onApprove={() => setDialog("approve")}
            onReset={resetDemo}
          />
        )}
      </Shell>

      <DialogLayer
        dialog={dialog}
        onClose={() => setDialog("none")}
        onConfirmApprove={confirmApprove}
        onConfirmExecute={confirmExecute}
        onCreateBatch={createBatch}
      />

      <div className={`toast${toast ? " is-visible" : ""}`} role="status" aria-live="polite">
        {toast}
      </div>
    </>
  );
}

export default App;
