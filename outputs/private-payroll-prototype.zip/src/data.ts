import type { AuditEvent, Recipient } from "./model";

export const recipients: Recipient[] = [
  {
    id: "maria-silva",
    name: "Maria Silva",
    region: "巴西",
    currency: "BRL",
    amount: "BRL 28,420.00",
    visibleTo: "薪资管理员",
    status: "已验证",
    payoutMethod: "本地银行",
    endpoint: "账户尾号 ·· 2048",
    privacyNote: "银行信息不上链；支付服务商仍会接收必要字段。",
  },
  {
    id: "chen-wei",
    name: "Chen Wei",
    region: "新加坡",
    currency: "USDC",
    amount: "USDC 9,860.00",
    visibleTo: "本人 + 审批人",
    status: "待审批",
    payoutMethod: "公开链稳定币",
    endpoint: "钱包 ·· 7F2A",
    privacyNote: "演示路线；真实公开链会暴露地址、金额与时间。",
  },
  {
    id: "amina-yusuf",
    name: "Amina Yusuf",
    region: "肯尼亚",
    currency: "USD",
    amount: "USD 5,740.00",
    visibleTo: "本人",
    status: "已封存",
    payoutMethod: "本地银行",
    endpoint: "账户尾号 ·· 8813",
    privacyNote: "当前仅保存演示指纹，不保存真实银行账号。",
  },
  {
    id: "jose-otero",
    name: "José Otero",
    region: "西班牙",
    currency: "EUR",
    amount: "EUR 7,980.00",
    visibleTo: "薪资管理员",
    status: "已验证",
    payoutMethod: "SEPA",
    endpoint: "IBAN 尾号 ·· 9016",
    privacyNote: "收款端点仅作脱敏展示，未连接银行验证。",
  },
];

export const initialAuditEvents: AuditEvent[] = [
  {
    id: "audit-1",
    time: "今天 09:42",
    actor: "Operator",
    action: "创建 8 月薪资批次",
    purpose: "常规月度发薪",
    result: "草稿已创建",
  },
  {
    id: "audit-2",
    time: "今天 10:18",
    actor: "Operator",
    action: "封存批次版本 v1",
    purpose: "提交审批",
    result: "流程封存模拟",
  },
];

export const roleMatrix = [
  {
    role: "员工",
    people: "仅本人",
    salary: "本人明细",
    destination: "本人完整端点",
    action: "选择收款方式",
  },
  {
    role: "薪资制单人",
    people: "职责范围",
    salary: "逐人净额",
    destination: "Token / 尾号",
    action: "编辑草稿",
  },
  {
    role: "财务审批人",
    people: "名单 + 异常",
    salary: "默认仅总额",
    destination: "指纹",
    action: "审批，不可编辑",
  },
  {
    role: "资金执行人",
    people: "不可见",
    salary: "资金需求",
    destination: "Token",
    action: "执行已批准批次",
  },
  {
    role: "审计 / 合规",
    people: "案件范围",
    salary: "限时、按字段",
    destination: "按授权披露",
    action: "只读导出",
  },
];
