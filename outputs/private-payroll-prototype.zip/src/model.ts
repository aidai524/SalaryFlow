export type Screen =
  | "overview"
  | "payroll"
  | "recipients"
  | "approvals"
  | "audit"
  | "privacy";

export type PayrollStage = "prepare" | "seal" | "approve" | "execute";

export type RecipientStatus =
  | "已验证"
  | "待审批"
  | "已封存"
  | "已审批"
  | "模拟完成";

export interface Recipient {
  id: string;
  name: string;
  region: string;
  currency: string;
  amount: string;
  visibleTo: string;
  status: RecipientStatus;
  payoutMethod: string;
  endpoint: string;
  privacyNote: string;
}

export interface AuditEvent {
  id: string;
  time: string;
  actor: string;
  action: string;
  purpose: string;
  result: string;
}

export type DialogKind = "none" | "approve" | "execute" | "newBatch";

export interface AppActions {
  openDialog: (kind: DialogKind) => void;
  navigate: (screen: Screen) => void;
}
