import {
  AlertTriangle,
  CheckCircle2,
  FilePlus2,
  ShieldCheck,
  X,
} from "lucide-react";
import { useEffect, useState } from "react";
import type { DialogKind } from "../model";

interface DialogLayerProps {
  dialog: DialogKind;
  onClose: () => void;
  onConfirmApprove: () => void;
  onConfirmExecute: () => void;
  onCreateBatch: (name: string, date: string, currency: string) => void;
}

export function DialogLayer({
  dialog,
  onClose,
  onConfirmApprove,
  onConfirmExecute,
  onCreateBatch,
}: DialogLayerProps) {
  const [batchName, setBatchName] = useState("9 月薪资批次");
  const [payDate, setPayDate] = useState("2026-09-30");
  const [currency, setCurrency] = useState("USDC");

  useEffect(() => {
    if (dialog === "none") return;
    const onKeyDown = (event: KeyboardEvent) => {
      if (event.key === "Escape") onClose();
    };
    window.addEventListener("keydown", onKeyDown);
    return () => window.removeEventListener("keydown", onKeyDown);
  }, [dialog, onClose]);

  if (dialog === "none") return null;

  const closeOnBackdrop = (event: React.MouseEvent<HTMLDivElement>) => {
    if (event.target === event.currentTarget) onClose();
  };

  if (dialog === "approve") {
    return (
      <div className="dialog-backdrop" onMouseDown={closeOnBackdrop}>
        <section className="dialog" role="dialog" aria-modal="true" aria-labelledby="approve-dialog-title">
          <DialogHeader title="批准批次" onClose={onClose} />
          <div className="dialog-body">
            <span className="dialog-symbol symbol-violet"><ShieldCheck size={28} /></span>
            <h2 id="approve-dialog-title">确认本地审批记录</h2>
            <p>你将批准 8 月薪资批次 v1，总额 USDC 84,620.00，覆盖 24 位收款人。</p>
            <div className="dialog-warning">
              <AlertTriangle size={19} aria-hidden="true" />
              <span>这不会验证身份、MFA 或真实批次签名，也不会移动资金。</span>
            </div>
            <label className="confirmation-check">
              <input type="checkbox" defaultChecked />
              <span>我理解这是研究原型中的本地演示动作</span>
            </label>
          </div>
          <div className="dialog-actions">
            <button className="button button-secondary" type="button" onClick={onClose}>取消</button>
            <button className="button button-primary" type="button" onClick={onConfirmApprove}>记录审批</button>
          </div>
        </section>
      </div>
    );
  }

  if (dialog === "execute") {
    return (
      <div className="dialog-backdrop" onMouseDown={closeOnBackdrop}>
        <section className="dialog dialog-execute" role="dialog" aria-modal="true" aria-labelledby="execute-dialog-title">
          <DialogHeader title="执行预检" onClose={onClose} />
          <div className="dialog-body">
            <span className="dialog-symbol symbol-blue"><CheckCircle2 size={28} /></span>
            <h2 id="execute-dialog-title">只模拟状态，不发送资金</h2>
            <p>审批条件已满足，但真实执行所需的外部检查均未接入。</p>
            <ul className="preflight-list">
              <li><span>KYC / KYB</span><strong>not_checked</strong></li>
              <li><span>制裁筛查</span><strong>not_checked</strong></li>
              <li><span>税务与工资媒介</span><strong>not_checked</strong></li>
              <li><span>资金余额 / 网络</span><strong>not_checked</strong></li>
            </ul>
            <div className="dialog-warning danger-warning">
              <AlertTriangle size={19} aria-hidden="true" />
              <span>没有支付 API、钱包签名、交易哈希或区块浏览器链接。</span>
            </div>
          </div>
          <div className="dialog-actions">
            <button className="button button-secondary" type="button" onClick={onClose}>返回</button>
            <button className="button button-primary" type="button" onClick={onConfirmExecute}>完成状态模拟</button>
          </div>
        </section>
      </div>
    );
  }

  return (
    <div className="dialog-backdrop" onMouseDown={closeOnBackdrop}>
      <section className="dialog" role="dialog" aria-modal="true" aria-labelledby="new-batch-dialog-title">
        <DialogHeader title="新建批次" onClose={onClose} />
        <form
          onSubmit={(event) => {
            event.preventDefault();
            onCreateBatch(batchName, payDate, currency);
          }}
        >
          <div className="dialog-body">
            <span className="dialog-symbol symbol-blue"><FilePlus2 size={28} /></span>
            <h2 id="new-batch-dialog-title">创建一个会话内草稿</h2>
            <p>草稿只存在于当前页面内存；刷新后消失，不会上传员工或收款数据。</p>
            <div className="form-grid">
              <label className="full-field">
                批次名称
                <input value={batchName} onChange={(event) => setBatchName(event.target.value)} required autoFocus />
              </label>
              <label>
                计划发薪日
                <input type="date" value={payDate} onChange={(event) => setPayDate(event.target.value)} required />
              </label>
              <label>
                默认结算币种
                <select value={currency} onChange={(event) => setCurrency(event.target.value)}>
                  <option>USDC</option>
                  <option>USD</option>
                  <option>EUR</option>
                </select>
              </label>
            </div>
            <p className="field-note">员工导入、余额、KYC、税务与收款端点验证：not_checked</p>
          </div>
          <div className="dialog-actions">
            <button className="button button-secondary" type="button" onClick={onClose}>取消</button>
            <button className="button button-primary" type="submit">创建本地草稿</button>
          </div>
        </form>
      </section>
    </div>
  );
}

function DialogHeader({ title, onClose }: { title: string; onClose: () => void }) {
  return (
    <header className="dialog-header">
      <strong>{title}</strong>
      <button className="icon-button" type="button" onClick={onClose} aria-label="关闭对话框">
        <X size={21} aria-hidden="true" />
      </button>
    </header>
  );
}
