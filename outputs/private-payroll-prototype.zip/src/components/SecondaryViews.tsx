import {
  ArrowRight,
  Check,
  CircleAlert,
  ExternalLink,
  EyeOff,
  FileKey2,
  Fingerprint,
  KeyRound,
  LockKeyhole,
  RotateCcw,
  ScanSearch,
  ShieldCheck,
  UserRoundCheck,
  UsersRound,
  WalletCards,
} from "lucide-react";
import { roleMatrix } from "../data";
import type { AuditEvent, Recipient, Screen } from "../model";

type RunState = "pending" | "approved" | "executed";

interface SecondaryViewsProps {
  screen: Exclude<Screen, "payroll">;
  recipients: Recipient[];
  events: AuditEvent[];
  runState: RunState;
  onNavigate: (screen: Screen) => void;
  onApprove: () => void;
  onReset: () => void;
}

const referenceProducts = [
  {
    name: "Request Finance",
    pattern: "批量支付、会计工作流、可选隐私结算",
    href: "https://help.request.finance/en/articles/12958312-private-payments-overview",
  },
  {
    name: "Rise",
    pattern: "收款人自主银行 / 钱包与链路去关联",
    href: "https://www.riseworks.io/blog/are-crypto-payroll-payments-on-rise-public",
  },
  {
    name: "Bitwage",
    pattern: "个人按比例分配银行与数字资产收款",
    href: "https://support.bitwage.com/updating-allocations-how-to-add-/-remove-your-bank-account-or-crypto-address",
  },
  {
    name: "Deel",
    pattern: "差异审核、多级审批与敏感字段权限",
    href: "https://help.letsdeel.com/hc/en-gb/articles/41690939621265-How-to-Enable-Automatic-Payroll-Submission-and-Approval",
  },
  {
    name: "Toku",
    pattern: "法币 / 稳定币混合与私密链实验路线",
    href: "https://www.toku.com/stablecoin-payroll",
  },
];

function PageFrame({ children }: { children: React.ReactNode }) {
  return <main className="secondary-page">{children}</main>;
}

function Overview({ onNavigate }: { onNavigate: (screen: Screen) => void }) {
  const layers = [
    {
      icon: UsersRound,
      title: "组织内最小可见",
      body: "普通经理只看状态与异常；逐人净额需职责范围或限时授权。",
    },
    {
      icon: Fingerprint,
      title: "批次不可悄改",
      body: "封存后若金额、名单或端点变化，应生成新版本并撤销旧审批。",
    },
    {
      icon: WalletCards,
      title: "结算泄漏分层",
      body: "银行、公开链、私密链看到的字段不同，不能用一个“Private”开关概括。",
    },
    {
      icon: ScanSearch,
      title: "合法选择性披露",
      body: "合规与监管仍可按案件获取必要字段；隐私不是匿名或绕过义务。",
    },
  ];

  return (
    <PageFrame>
      <section className="secondary-heading overview-heading">
        <div>
          <h1>工资不是谁都不能看</h1>
          <p>而是谁都只能在需要时，看完成职责所需的部分。</p>
        </div>
        <button className="button button-primary" type="button" onClick={() => onNavigate("payroll")}>
          打开 8 月批次
          <ArrowRight size={18} aria-hidden="true" />
        </button>
      </section>

      <section className="prototype-boundary" aria-label="原型边界">
        <CircleAlert size={24} aria-hidden="true" />
        <div>
          <strong>研究原型，不是支付产品</strong>
          <p>遮罩、封存、审批、审计与执行均为前端模拟；KYC、税务、制裁与资金状态统一标为 not_checked。</p>
        </div>
      </section>

      <section className="layer-list" aria-labelledby="layer-title">
        <div className="section-intro">
          <h2 id="layer-title">四层隐私模型</h2>
          <p>把应用权限、批次治理、结算可见性与法定披露分开设计。</p>
        </div>
        {layers.map(({ icon: Icon, title, body }, index) => (
          <article key={title} className="layer-row">
            <span className="layer-index">0{index + 1}</span>
            <span className="layer-icon"><Icon size={22} aria-hidden="true" /></span>
            <h3>{title}</h3>
            <p>{body}</p>
          </article>
        ))}
      </section>

      <section className="reference-section" aria-labelledby="reference-title">
        <div className="section-intro">
          <h2 id="reference-title">案例启发</h2>
          <p>链接指向本次核对过的官方资料；能力是否对所有地区开放仍需销售与合同确认。</p>
        </div>
        <div className="reference-list">
          {referenceProducts.map((product) => (
            <a key={product.name} href={product.href} target="_blank" rel="noreferrer">
              <strong>{product.name}</strong>
              <span>{product.pattern}</span>
              <ExternalLink size={16} aria-hidden="true" />
            </a>
          ))}
        </div>
      </section>
    </PageFrame>
  );
}

function Recipients({ recipients }: { recipients: Recipient[] }) {
  return (
    <PageFrame>
      <section className="secondary-heading">
        <div>
          <h1>收款人</h1>
          <p>员工维护收款偏好；雇主侧只显示脱敏端点与验证状态。</p>
        </div>
      </section>
      <section className="plain-table-section">
        <div className="table-title-row">
          <div>
            <h2>收款路线</h2>
            <p>示例数据均为虚构；未调用银行、钱包或身份验证服务。</p>
          </div>
          <span className="not-checked-label">验证状态 · not_checked</span>
        </div>
        <div className="table-scroll">
          <table>
            <thead>
              <tr>
                <th>收款人</th>
                <th>地区</th>
                <th>路线</th>
                <th>脱敏端点</th>
                <th>外部验证</th>
              </tr>
            </thead>
            <tbody>
              {recipients.map((recipient) => (
                <tr key={recipient.id}>
                  <td><strong>{recipient.name}</strong></td>
                  <td>{recipient.region}</td>
                  <td>{recipient.payoutMethod}</td>
                  <td className="mono-value">{recipient.endpoint}</td>
                  <td><span className="not-checked-label">not_checked</span></td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </section>
      <section className="route-warning">
        <EyeOff size={22} aria-hidden="true" />
        <div>
          <strong>公开链不是隐私轨道</strong>
          <p>它会公开地址、金额与时间；“地址看不出姓名”不等于工资不可关联。</p>
        </div>
      </section>
    </PageFrame>
  );
}

function Approvals({ runState, onApprove }: { runState: RunState; onApprove: () => void }) {
  const approved = runState !== "pending";
  return (
    <PageFrame>
      <section className="secondary-heading">
        <div>
          <h1>审批</h1>
          <p>制单、复核和执行分离；审批人签的是同一个批次版本。</p>
        </div>
        <button className="button button-primary" type="button" disabled={approved} onClick={onApprove}>
          {approved ? <Check size={18} /> : null}
          {approved ? "本地审批已记录" : "批准演示批次"}
        </button>
      </section>

      <section className="manifest-panel" aria-labelledby="manifest-title">
        <div className="manifest-header">
          <span className="manifest-icon"><FileKey2 size={24} aria-hidden="true" /></span>
          <div>
            <h2 id="manifest-title">8 月薪资批次 · v1</h2>
            <p>流程封存模拟，非密码学封存</p>
          </div>
          <span className="manifest-state">{approved ? "已审批" : "审批中"}</span>
        </div>
        <dl className="manifest-grid">
          <div><dt>收款人数</dt><dd>24</dd></div>
          <div><dt>资金需求</dt><dd>USDC 84,620.00</dd></div>
          <div><dt>版本摘要</dt><dd className="mono-value">demo:8fc2…9a4d</dd></div>
          <div><dt>外部预检</dt><dd className="not-checked-label">not_checked</dd></div>
        </dl>
      </section>

      <section className="approval-chain" aria-labelledby="chain-title">
        <div className="section-intro">
          <h2 id="chain-title">2 人复核</h2>
          <p>真实系统应验证独立身份、MFA、职责分离和同一 manifest hash。</p>
        </div>
        <ol>
          <li className="is-done">
            <span><Check size={18} /></span>
            <div><strong>薪资制单</strong><p>Operator · 今天 10:18</p></div>
            <small>已提交</small>
          </li>
          <li className={approved ? "is-done" : "is-current"}>
            <span>{approved ? <Check size={18} /> : "2"}</span>
            <div><strong>财务复核</strong><p>{approved ? "Finance Approver · 刚刚" : "等待 Finance Approver"}</p></div>
            <small>{approved ? "已记录" : "待审批"}</small>
          </li>
          <li>
            <span>3</span>
            <div><strong>资金执行</strong><p>仅在审批完成后开放</p></div>
            <small>{runState === "executed" ? "模拟完成" : "未开始"}</small>
          </li>
        </ol>
      </section>
    </PageFrame>
  );
}

function Audit({ events, onReset }: { events: AuditEvent[]; onReset: () => void }) {
  return (
    <PageFrame>
      <section className="secondary-heading">
        <div>
          <h1>审计日志</h1>
          <p>记录谁在何时、以什么理由查看或改变了演示状态。</p>
        </div>
        <button className="button button-secondary" type="button" onClick={onReset}>
          <RotateCcw size={17} aria-hidden="true" />
          重置演示
        </button>
      </section>
      <section className="prototype-boundary compact-boundary">
        <CircleAlert size={22} aria-hidden="true" />
        <div>
          <strong>可修改的内存记录</strong>
          <p>刷新页面会恢复初始值；这不是独立存储、WORM 或防篡改审计。</p>
        </div>
      </section>
      <section className="audit-list" aria-label="本地活动记录">
        {events.map((event, index) => (
          <article key={event.id}>
            <span className="audit-marker" aria-hidden="true">{index + 1}</span>
            <time>{event.time}</time>
            <div className="audit-copy">
              <strong>{event.action}</strong>
              <p>{event.actor} · {event.purpose}</p>
            </div>
            <span className="audit-result">{event.result}</span>
          </article>
        ))}
      </section>
    </PageFrame>
  );
}

function Privacy() {
  return (
    <PageFrame>
      <section className="secondary-heading">
        <div>
          <h1>隐私设置</h1>
          <p>角色预览帮助讨论策略，但不构成真实访问控制。</p>
        </div>
        <span className="persona-preview-label"><KeyRound size={16} /> Persona preview</span>
      </section>
      <section className="plain-table-section role-matrix">
        <div className="table-title-row">
          <div>
            <h2>最小权限矩阵</h2>
            <p>生产版还需服务端 RBAC + ABAC、字段加密、MFA 和限时授权。</p>
          </div>
        </div>
        <div className="table-scroll">
          <table>
            <thead>
              <tr><th>角色</th><th>人员信息</th><th>工资数据</th><th>收款端点</th><th>允许动作</th></tr>
            </thead>
            <tbody>
              {roleMatrix.map((row) => (
                <tr key={row.role}>
                  <td><strong>{row.role}</strong></td>
                  <td>{row.people}</td>
                  <td>{row.salary}</td>
                  <td>{row.destination}</td>
                  <td>{row.action}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </section>
      <section className="privacy-notes">
        <article><LockKeyhole size={22} /><div><strong>字段加密</strong><p>未实现。浏览器内仅用 CSS 遮罩显示效果。</p></div></article>
        <article><UserRoundCheck size={22} /><div><strong>限时解封</strong><p>已做交互模拟；未验证身份、工单或 MFA。</p></div></article>
        <article><ShieldCheck size={22} /><div><strong>法定披露</strong><p>应按案件、期间和字段授权，且保留独立审计。</p></div></article>
      </section>
    </PageFrame>
  );
}

export function SecondaryViews({
  screen,
  recipients,
  events,
  runState,
  onNavigate,
  onApprove,
  onReset,
}: SecondaryViewsProps) {
  switch (screen) {
    case "overview":
      return <Overview onNavigate={onNavigate} />;
    case "recipients":
      return <Recipients recipients={recipients} />;
    case "approvals":
      return <Approvals runState={runState} onApprove={onApprove} />;
    case "audit":
      return <Audit events={events} onReset={onReset} />;
    case "privacy":
      return <Privacy />;
  }
}
