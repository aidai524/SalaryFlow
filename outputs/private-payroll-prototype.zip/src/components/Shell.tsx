import {
  Bell,
  CheckCircle2,
  ChevronDown,
  ClipboardList,
  FileClock,
  FileText,
  LayoutDashboard,
  LockKeyhole,
  ShieldCheck,
  Users,
} from "lucide-react";
import type { ReactNode } from "react";
import type { Screen } from "../model";

const navigation: Array<{
  id: Screen;
  label: string;
  icon: typeof LayoutDashboard;
}> = [
  { id: "overview", label: "概览", icon: LayoutDashboard },
  { id: "payroll", label: "薪资批次", icon: FileText },
  { id: "recipients", label: "收款人", icon: Users },
  { id: "approvals", label: "审批", icon: CheckCircle2 },
  { id: "audit", label: "审计日志", icon: ClipboardList },
  { id: "privacy", label: "隐私设置", icon: ShieldCheck },
];

interface ShellProps {
  screen: Screen;
  onNavigate: (screen: Screen) => void;
  children: ReactNode;
}

export function Shell({ screen, onNavigate, children }: ShellProps) {
  return (
    <div className="app-shell">
      <aside className="sidebar" aria-label="主导航">
        <button
          className="brand"
          type="button"
          onClick={() => onNavigate("payroll")}
          aria-label="返回薪资批次"
        >
          <span className="brand-mark" aria-hidden="true">
            <LockKeyhole size={19} strokeWidth={2.2} />
          </span>
          <span className="brand-copy">
            <strong>Private Payroll</strong>
            <small>隐私薪资台</small>
          </span>
        </button>

        <nav className="primary-nav">
          {navigation.map(({ id, label, icon: Icon }) => (
            <button
              key={id}
              type="button"
              className={`nav-item${screen === id ? " is-active" : ""}`}
              onClick={() => onNavigate(id)}
              aria-current={screen === id ? "page" : undefined}
              aria-label={label}
            >
              <Icon size={21} strokeWidth={1.75} aria-hidden="true" />
              <span>{label}</span>
            </button>
          ))}
        </nav>

        <div className="sidebar-foot">
          <div className="avatar" aria-hidden="true">
            OP
          </div>
          <div className="operator-copy">
            <strong>Operator</strong>
            <span>薪资管理员</span>
          </div>
          <ChevronDown size={16} aria-hidden="true" />
        </div>
      </aside>

      <section className="app-main">
        <header className="topbar">
          <span className="topbar-context">
            <FileClock size={17} aria-hidden="true" />
            研究原型 · 2026-08-04
          </span>
          <span className="environment-status">
            <span className="status-dot" aria-hidden="true" />
            演示环境 · 未连接真实资金
          </span>
          <button className="icon-button notification-button" type="button" aria-label="通知">
            <Bell size={20} strokeWidth={1.8} aria-hidden="true" />
            <span className="notification-dot" aria-hidden="true" />
          </button>
        </header>
        {children}
      </section>
    </div>
  );
}
