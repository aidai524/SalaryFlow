import {
  ArrowLeft,
  Check,
  CheckCircle2,
  Circle,
  Clock3,
  EyeOff,
  FileKey2,
  KeyRound,
  MoreVertical,
  Plus,
  ShieldCheck,
  UserRoundCheck,
  X,
} from "lucide-react";
import { useEffect, useState } from "react";
import type { DialogKind, Recipient, RecipientStatus } from "../model";

type RunState = "pending" | "approved" | "executed";

interface PayrollViewProps {
  recipients: Recipient[];
  selectedId: string;
  revealedIds: Set<string>;
  runState: RunState;
  onSelect: (id: string) => void;
  onGrantAccess: (id: string, reason: string, ticket: string) => void;
  onHide: (id: string) => void;
  onOpenDialog: (kind: DialogKind) => void;
}

const stepLabels = ["准备", "封存", "审批", "执行"];

function statusMeta(status: RecipientStatus) {
  switch (status) {
    case "已验证":
      return { tone: "green", icon: CheckCircle2 };
    case "待审批":
      return { tone: "amber", icon: Clock3 };
    case "已封存":
      return { tone: "violet", icon: FileKey2 };
    case "已审批":
      return { tone: "blue", icon: UserRoundCheck };
    case "模拟完成":
      return { tone: "green", icon: CheckCircle2 };
  }
}

function currentStep(runState: RunState) {
  if (runState === "pending") return 2;
  if (runState === "approved") return 3;
  return 4;
}

export function PayrollView({
  recipients,
  selectedId,
  revealedIds,
  runState,
  onSelect,
  onGrantAccess,
  onHide,
  onOpenDialog,
}: PayrollViewProps) {
  const selected =
    recipients.find((recipient) => recipient.id === selectedId) ?? recipients[0];
  const isRevealed = revealedIds.has(selected.id);
  const [drawerOpen, setDrawerOpen] = useState(true);
  const [requestOpen, setRequestOpen] = useState(false);
  const [reason, setReason] = useState("薪资核对");
  const [ticket, setTicket] = useState("PP-2408");
  const step = currentStep(runState);

  useEffect(() => {
    setRequestOpen(false);
    setReason("薪资核对");
    setTicket("PP-2408");
    setDrawerOpen(true);
  }, [selected.id]);

  const selectRecipient = (id: string) => {
    onSelect(id);
    setDrawerOpen(true);
  };

  const actionLabel =
    runState === "pending"
      ? "批准批次"
      : runState === "approved"
        ? "模拟执行"
        : "模拟已完成";

  return (
    <div className={`workspace-layout${drawerOpen ? "" : " drawer-is-closed"}`}>
      <main className="payroll-workspace">
        <section className="page-heading" aria-labelledby="payroll-title">
          <div>
            <h1 id="payroll-title">8 月薪资批次</h1>
            <p>敏感工资按角色解密；付款执行为本地模拟。</p>
          </div>
          <button
            className="button button-primary new-run-button"
            type="button"
            onClick={() => onOpenDialog("newBatch")}
          >
            <Plus size={20} strokeWidth={2} aria-hidden="true" />
            新建批次
          </button>
        </section>

        <section className="summary-band" aria-label="批次摘要">
          <div className="summary-item summary-total">
            <span>批次总额</span>
            <strong>USDC 84,620.00</strong>
            <small>审批人仅见聚合值</small>
          </div>
          <div className="summary-item">
            <span>收款人数</span>
            <strong>24</strong>
            <small>4 条示例明细</small>
          </div>
          <div className="summary-item">
            <span>待审批</span>
            <strong className={runState === "pending" ? "attention" : "resolved"}>
              {runState === "pending" ? "2" : "0"}
            </strong>
            <small>{runState === "pending" ? "需双人复核" : "审批条件已满足"}</small>
          </div>
        </section>

        <ol className="workflow-rail" aria-label="薪资批次进度">
          {stepLabels.map((label, index) => {
            const isComplete = index < step;
            const isCurrent = index === step;
            return (
              <li
                key={label}
                className={`${isComplete ? "is-complete" : ""} ${isCurrent ? "is-current" : ""}`}
                aria-current={isCurrent ? "step" : undefined}
              >
                <span className="step-node" aria-hidden="true">
                  {isComplete ? <Check size={17} /> : index + 1}
                </span>
                <span>{label}</span>
              </li>
            );
          })}
        </ol>

        <section className="recipient-table-section" aria-labelledby="recipient-table-title">
          <div className="table-title-row">
            <div>
              <h2 id="recipient-table-title">收款明细</h2>
              <p>个人净额默认遮蔽；选择一行查看授权范围。</p>
            </div>
            <span className="table-scope">
              <ShieldCheck size={16} aria-hidden="true" />
              最小可见
            </span>
          </div>
          <div className="table-scroll">
            <table>
              <thead>
                <tr>
                  <th scope="col">收款人</th>
                  <th scope="col">地区</th>
                  <th scope="col">币种</th>
                  <th scope="col">净额</th>
                  <th scope="col">可见范围</th>
                  <th scope="col">状态</th>
                  <th scope="col"><span className="sr-only">操作</span></th>
                </tr>
              </thead>
              <tbody>
                {recipients.map((recipient) => {
                  const selectedRow = recipient.id === selected.id;
                  const revealed = revealedIds.has(recipient.id);
                  const displayStatus: RecipientStatus =
                    runState === "executed"
                      ? "模拟完成"
                      : runState === "approved" && recipient.status === "待审批"
                        ? "已审批"
                        : recipient.status;
                  const meta = statusMeta(displayStatus);
                  const StatusIcon = meta.icon;
                  return (
                    <tr key={recipient.id} className={selectedRow ? "is-selected" : ""}>
                      <td>
                        <button
                          type="button"
                          className="row-selector"
                          onClick={() => selectRecipient(recipient.id)}
                          aria-pressed={selectedRow}
                        >
                          {recipient.name}
                        </button>
                      </td>
                      <td>{recipient.region}</td>
                      <td>{recipient.currency}</td>
                      <td className="amount-cell">
                        {revealed ? (
                          <span className="revealed-amount">{recipient.amount}</span>
                        ) : (
                          <button
                            type="button"
                            className="masked-amount"
                            onClick={() => selectRecipient(recipient.id)}
                            aria-label={`${recipient.name} 的净额已隐藏，选择以申请访问`}
                          >
                            <span aria-hidden="true">••••••</span>
                            <EyeOff size={16} strokeWidth={1.75} aria-hidden="true" />
                          </button>
                        )}
                      </td>
                      <td>{recipient.visibleTo}</td>
                      <td>
                        <span className={`status-text tone-${meta.tone}`}>
                          <StatusIcon size={17} strokeWidth={1.8} aria-hidden="true" />
                          {displayStatus}
                        </span>
                      </td>
                      <td>
                        <button
                          className="icon-button row-menu"
                          type="button"
                          aria-label={`${recipient.name} 的更多操作`}
                          onClick={() => selectRecipient(recipient.id)}
                        >
                          <MoreVertical size={18} aria-hidden="true" />
                        </button>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </section>

        <footer className="payroll-actions">
          <div className="simulation-note">
            <ShieldCheck size={22} strokeWidth={1.7} aria-hidden="true" />
            <span>
              <strong>本地演示状态</strong>
              未验证独立身份或 MFA，不会发起付款。
            </span>
          </div>
          <div className="action-group">
            <button className="button button-secondary" type="button">
              <ArrowLeft size={17} aria-hidden="true" />
              返回编辑
            </button>
            <button
              className="button button-primary approval-button"
              type="button"
              disabled={runState === "executed"}
              onClick={() =>
                onOpenDialog(runState === "approved" ? "execute" : "approve")
              }
            >
              {runState === "executed" ? <CheckCircle2 size={18} /> : null}
              {actionLabel}
            </button>
          </div>
        </footer>
      </main>

      {drawerOpen ? <aside className="access-drawer" aria-label={`${selected.name} 的访问详情`}>
        <div className="drawer-heading">
          <div>
            <span className="drawer-context">{selected.name}</span>
            <h2>选择性披露</h2>
          </div>
          <button className="icon-button" type="button" aria-label="关闭详情" onClick={() => setDrawerOpen(false)}>
            <X size={21} aria-hidden="true" />
          </button>
        </div>

        {isRevealed ? (
          <section className="reveal-state" aria-live="polite">
            <div className="reveal-icon"><KeyRound size={24} aria-hidden="true" /></div>
            <div>
              <span>临时访问已授予</span>
              <strong>{selected.amount}</strong>
              <small>29:59 后自动隐藏 · 本地模拟</small>
            </div>
          </section>
        ) : (
          <section className="access-callout">
            <ShieldCheck size={28} strokeWidth={1.7} aria-hidden="true" />
            <p>你当前只能查看批次总额，不能查看个人净额。</p>
          </section>
        )}

        <div className="access-rail">
          <span className="rail-dot rail-dot-top" aria-hidden="true" />
          <span className="rail-key" aria-hidden="true"><KeyRound size={17} /></span>
          <dl className="access-facts">
            <div>
              <dt>访问理由</dt>
              <dd>{isRevealed ? reason : "薪资核对"}</dd>
            </div>
            <div>
              <dt>授权人</dt>
              <dd>薪资主管</dd>
            </div>
            <div>
              <dt>有效期</dt>
              <dd className="violet-value">30 分钟</dd>
            </div>
          </dl>
        </div>

        <section className="destination-summary" aria-labelledby="destination-title">
          <h3 id="destination-title">收款路线</h3>
          <div>
            <span>{selected.payoutMethod}</span>
            <strong>{selected.endpoint}</strong>
          </div>
          <p>{selected.privacyNote}</p>
        </section>

        <section className="visibility-receipt" aria-labelledby="visibility-title">
          <h3 id="visibility-title">可见性回执</h3>
          <ul>
            <li><span>同事 / 公众</span><strong className="receipt-hidden">隐藏</strong></li>
            <li><span>财务审批人</span><strong>批次总额</strong></li>
            <li><span>工资服务商</span><strong className="receipt-pending">not_checked</strong></li>
            <li><span>监管 / 合规</span><strong>按案件授权</strong></li>
          </ul>
        </section>

        {requestOpen && !isRevealed ? (
          <form
            className="access-request-form"
            onSubmit={(event) => {
              event.preventDefault();
              onGrantAccess(selected.id, reason, ticket);
              setRequestOpen(false);
            }}
          >
            <label>
              访问理由
              <select value={reason} onChange={(event) => setReason(event.target.value)}>
                <option>薪资核对</option>
                <option>异常调查</option>
                <option>法定披露</option>
              </select>
            </label>
            <label>
              工单号
              <input
                value={ticket}
                onChange={(event) => setTicket(event.target.value)}
                required
                aria-describedby="ticket-help"
              />
            </label>
            <p id="ticket-help">原型不验证工单或 MFA。</p>
            <div className="drawer-buttons">
              <button className="button button-primary" type="submit">确认临时访问</button>
              <button className="button button-quiet" type="button" onClick={() => setRequestOpen(false)}>取消</button>
            </div>
          </form>
        ) : (
          <div className="drawer-buttons drawer-buttons-bottom">
            {isRevealed ? (
              <button className="button button-primary" type="button" onClick={() => onHide(selected.id)}>
                立即重新隐藏
              </button>
            ) : (
              <button className="button button-primary" type="button" onClick={() => setRequestOpen(true)}>
                申请临时访问
              </button>
            )}
            <button
              className="button button-secondary"
              type="button"
              onClick={() => onHide(selected.id)}
            >
              保持隐藏
            </button>
          </div>
        )}

        <p className="drawer-disclaimer">
          界面遮罩不等于加密；角色预览不是服务端访问控制。
        </p>
      </aside> : null}
    </div>
  );
}
