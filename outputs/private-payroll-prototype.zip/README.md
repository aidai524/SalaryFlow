# Private Payroll / 隐私薪资台

一个基于 Request Finance、Rise、Bitwage、Deel、Toku 产品模式整理的隐私工资支付研究原型。

## 运行

```bash
npm install
npm run dev
```

打开终端打印的本地地址。生产构建：

```bash
npm run build
```

## 已实现的原型闭环

- 默认遮蔽个人净额；选中收款人查看可见范围与收款路线。
- 选择理由与工单号，模拟 30 分钟临时解封，再立即重新隐藏。
- 批次准备、封存、审批、执行状态流转。
- 审批前确认、执行前 `not_checked` 预检与“未发送资金”结果。
- 本地活动记录、收款人路线、审批链、角色权限矩阵。
- 桌面与移动布局；键盘焦点、语义化控件与 reduced-motion 支持。

## 真实边界

这是纯前端研究原型：

- 界面遮罩不等于加密。
- Persona preview 不等于服务端 RBAC / ABAC。
- 封存没有服务器签名或不可变存储。
- 审批没有独立身份、MFA 或真实签名验证。
- 审计记录存在内存中，不防篡改，刷新后恢复初始值。
- KYC/KYB、制裁、税务、余额、网络均为 `not_checked`。
- 没有支付 API、钱包签名、交易哈希或真实资金移动。

## 项目结构

- `src/components/PayrollView.tsx`：薪资批次与选择性披露主流程。
- `src/components/Dialogs.tsx`：审批、模拟执行、新建批次。
- `src/components/SecondaryViews.tsx`：概览、收款人、审批、审计与隐私矩阵。
- `src/data.ts`：虚构示例收款人与初始活动记录。
- `src/styles.css`：完整视觉系统与响应式布局。

